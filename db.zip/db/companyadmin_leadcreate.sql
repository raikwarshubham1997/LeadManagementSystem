-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2022 at 07:58 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `companyadmin_leadcreate`
--

CREATE TABLE `companyadmin_leadcreate` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `middle_name` varchar(150) DEFAULT NULL,
  `last_name` varchar(150) NOT NULL,
  `gender` varchar(150) NOT NULL,
  `birthday` date NOT NULL,
  `email` varchar(150) NOT NULL,
  `intrested` varchar(150) NOT NULL,
  `lead_sources` varchar(150) NOT NULL,
  `remarks` longtext NOT NULL,
  `assigned_id` int(11) NOT NULL,
  `status` varchar(150) NOT NULL,
  `date_create` date DEFAULT current_timestamp(),
  `contact` varchar(12) NOT NULL,
  `address` varchar(300) NOT NULL,
  `alternat_no` varchar(12) NOT NULL,
  `permanent_address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `companyadmin_leadcreate`
--

INSERT INTO `companyadmin_leadcreate` (`id`, `first_name`, `middle_name`, `last_name`, `gender`, `birthday`, `email`, `intrested`, `lead_sources`, `remarks`, `assigned_id`, `status`, `date_create`, `contact`, `address`, `alternat_no`, `permanent_address`) VALUES
(4, 'demo', 'kumar', 'Lowansi', 'male', '2000-06-22', 'aditya@gmail.com', 'Python', 'Facebook Ad', 'Facebook Ads only', 4, 'Open', '2022-12-01', '9098976653', 'Jalandhar fdfd', '3447477334', 'indore'),
(5, 'Sakshi', 'Gd', 'Gour', 'female', '2002-07-18', 'sakshi@gmail.com', 'Android', 'Other Sources', 'Amazon', 5, 'Not a Target', '2022-12-01', '6260557690', 'Ujjain', '3424234132', '1'),
(6, 'Deepak', 'wqw', 'verma', 'male', '1999-12-04', 'deepak32@gmail.com', 'Php', 'Company Website', 'Facebook Ads only', 5, 'Disqualified', '2022-12-01', '7345628723', 'Bhopal', '2342421323', '1'),
(12, 'Rolf', 'K', 'Smith', 'male', '2022-11-03', 'rolf4@gmail.com', 'Python', 'fbad', 'Facebook Ads only', 5, 'Not a Target', '2022-12-01', '4674774334', 'Savitri Empier, Indore Madhya Pradesh', '3232323233', '1'),
(13, 'Sachin', 'K', 'Soni', 'male', '2000-07-11', 'sachin@gmail.com', 'Android', 'goads', 'google Ads only', 1, 'Open', '2022-12-01', '9987878898', 'Indore Madhya Pradesh', '88889999778', 'H.NO 23 zzz indore'),
(14, 'demo', 'wqw', 'verma', 'male', '2005-02-09', 'demo221@gmail.com', 'Android', 'goads', 'fghfghj', 5, 'New/Prospect', '2022-12-01', '4354657567', 'Banglore', '2343453453', 'H.NO 23 ABC colony Raipur'),
(15, 'dsaas', 'sda', 'dasda', 'male', '1999-01-19', 'grtyrh@gmail.com', 'Python', 'os', 'fghfghj', 4, 'New/Prospect', '2022-12-01', '2323435334', 'Indore Madhya Pradesh', '45645575', 'H.NO 23 zzz indore'),
(16, 'Aman', '', 'abc', 'male', '2022-11-16', 'aman@gmail.com', 'Product Sale', 'companysite', 'Product Advitisment', 5, 'Working', '2022-12-01', '9987878890', 'H.No 43 Savitri Empier', '6655467784', 'Indore'),
(21, 'Satya', 'M', 'shrivastav', 'male', '2002-12-22', 'satya12@gmail.com', 'Django', 'Other Sources', 'ads', 4, 'New/Prospect', '2022-12-01', '888498488', 'Hno 342 Sarowar residency', '7676776778', 'Indore'),
(22, 'Divya', '', 'Rathore', 'female', '1999-06-05', 'divya@gmail.com', 'Android', 'Google', 'Improve product', 5, 'Working', '2022-12-01', '9984477833', 'HNO 111 Ring road ', '7676888933', 'Indore'),
(23, 'Yash', 'K', 'Smith', 'male', '2022-11-06', 'yash@gmail.com', 'Python', 'fbad', 'Facebook Ads only', 5, 'Not a Target', NULL, '4674774334', 'Savitri Empier, Indore Madhya Pradesh', '3232323233', 'Savitri Empier, Indore Madhya Pradesh'),
(24, 'Depika', 'wqw', 'verma', 'female', '1999-12-10', 'depika@gmail.com', 'Php', 'Company Website', 'Facebook Ads only', 5, 'Disqualified', NULL, '7345628723', 'Bhopal', '2342421323', 'Bhopal'),
(29, 'Umesh', 'Gd', 'Gour', 'male', '2002-07-11', 'umesh@gmail.com', 'Android', 'Other Sources', 'Amazon', 3, 'Not a Target', NULL, '6260557690', 'Ujjain', '3424234132', 'Ujjain'),
(30, 'Shani', 'kumar', 'Jha', 'male', '2000-06-12', 'shani@gmail.com', 'Python', 'Facebook Ad', 'Facebook Ads only', 4, 'Open', NULL, '9098976653', 'Jalandhar fdfd', '3447477334', 'Jalandhar fdfd'),
(31, 'Umesh', 'Gd', 'Gour', 'male', '2002-07-11', 'umesh@gmail.com', 'Android', 'Other Sources', 'Amazon', 3, 'Not a Target', NULL, '6260557690', 'Ujjain', '3424234132', 'Ujjain'),
(32, 'Shani', 'kumar', 'Jha', 'male', '2000-06-12', 'shani@gmail.com', 'Python', 'Facebook Ad', 'Facebook Ads only', 4, 'Open', NULL, '9098976653', 'Jalandhar fdfd', '3447477334', 'Jalandhar fdfd'),
(38, 'Jay', 'Gd', 'Prakash', 'male', '2002-07-11', 'jay@gmail.com', 'Android', 'Other Sources', 'Amazon', 3, 'Not a Target', NULL, '6260557690', 'Ujjain', '3424234132', 'Ujjain'),
(39, 'isha', NULL, 'Jha', 'female', '2000-06-12', 'isha@gmail.com', 'Python', 'Facebook Ad', 'Facebook Ads only', 4, 'Open', NULL, '9098976653', 'Jalandhar fdfd', '3447477334', 'Jalandhar fdfd'),
(40, 'Jay', 'Gd', 'Prakash', 'male', '2002-07-11', 'jay@gmail.com', 'Android', 'Other Sources', 'Amazon', 3, 'Not a Target', NULL, '6260557690', 'Ujjain', '3424234132', 'Ujjain'),
(41, 'isha', NULL, 'Jha', 'female', '2000-06-12', 'isha@gmail.com', 'Python', 'Facebook Ad', 'Facebook Ads only', 4, 'Open', NULL, '9098976653', 'Jalandhar fdfd', '3447477334', 'Jalandhar fdfd'),
(42, 'Jay', 'Gd', 'Prakash', 'male', '2002-07-11', 'jay@gmail.com', 'Android', 'Other Sources', 'Amazon', 3, 'Not a Target', NULL, '6260557690', 'Ujjain', '3424234132', 'Ujjain'),
(43, 'isha', NULL, 'Jha', 'female', '2000-06-12', 'isha@gmail.com', 'Python', 'Facebook Ad', 'Facebook Ads only', 4, 'Open', NULL, '9098976653', 'Jalandhar fdfd', '3447477334', 'Jalandhar fdfd'),
(44, 'Jay', 'Gd', 'Prakash', 'male', '2002-07-11', 'jay@gmail.com', 'Android', 'Other Sources', 'Amazon', 3, 'Not a Target', NULL, '6260557690', 'Ujjain', '3424234132', 'Ujjain'),
(45, 'isha', NULL, 'Jha', 'female', '2000-06-12', 'isha@gmail.com', 'Python', 'Facebook Ad', 'Facebook Ads only', 4, 'Open', NULL, '9098976653', 'Jalandhar fdfd', '3447477334', 'Jalandhar fdfd'),
(50, 'Sara', 'Ali', 'Khan', 'female', '2000-11-22', 'sara@gmail.com', 'dsd', 'Google Ads', 'dwdw', 3, 'Not a target', NULL, '9984884483', 'Indore', '7746467772', 'Bhopal'),
(51, 'Sara', 'Ali', 'Khan', 'female', '2000-11-22', 'sara@gmail.com', 'dsd', 'Google Ads', 'dwdw', 3, 'Not a target', NULL, '9984884483', 'Indore', '7746467772', 'Bhopal'),
(52, 'Sara', 'Ali', 'Khan', 'female', '2000-11-22', 'sara@gmail.com', 'dsd', 'Google Ads', 'dwdw', 3, 'Not a target', NULL, '9984884483', 'Indore', '7746467772', 'Bhopal'),
(53, 'wsq', 'wqw', 'wq', 'male', '2022-12-13', 'ro121hit@gmail.com', 'Android', 'companysite', 'Amazon', 3, 'Open', '0000-00-00', '4354657567', 'sqw', '32312212121', 'qw'),
(54, 'Dazy', '', 'Saha', 'female', '2022-12-15', 'dazy@gmail.com', 'dsd', 'fbad', 'qwqwq', 6, 'Disqualified', '0000-00-00', '2323435334', 'sdasd', '4344435565', 'sd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companyadmin_leadcreate`
--
ALTER TABLE `companyadmin_leadcreate`
  ADD PRIMARY KEY (`id`),
  ADD KEY `companyAdmin_leadcreate_assigned_id_16c04a7f` (`assigned_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companyadmin_leadcreate`
--
ALTER TABLE `companyadmin_leadcreate`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `companyadmin_leadcreate`
--
ALTER TABLE `companyadmin_leadcreate`
  ADD CONSTRAINT `companyAdmin_leadcreate_assigned_id_16c04a7f_fk_auth_user_id` FOREIGN KEY (`assigned_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
