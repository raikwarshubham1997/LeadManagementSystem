from django.apps import AppConfig


class WorkingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Employee'
