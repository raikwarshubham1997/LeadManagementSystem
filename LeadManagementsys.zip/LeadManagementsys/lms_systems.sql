-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2022 at 01:57 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms_systems`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins_manager`
--

CREATE TABLE `admins_manager` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(30) NOT NULL,
  `created_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins_manager`
--

INSERT INTO `admins_manager` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `created_by_id`) VALUES
(1, 'Pragati', 'Sharma', 'pragati@123', 'pragatisharma270@gmail.com', '12345', 2),
(3, 'Sachin', 'Deshmukh', 'sachin@123', 'sachin@gmail.com', '12345', 2),
(4, 'Satish', 'Verma', 'satish', 'satish@gmain.com', '12345', 2),
(5, 'sddd', 'ds', 'sddsd', 'dfgdfgdfgd@gmail.com', '12345', 2);

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add team lead_ register', 7, 'add_teamlead_register'),
(26, 'Can change team lead_ register', 7, 'change_teamlead_register'),
(27, 'Can delete team lead_ register', 7, 'delete_teamlead_register'),
(28, 'Can view team lead_ register', 7, 'view_teamlead_register'),
(29, 'Can add manager', 8, 'add_manager'),
(30, 'Can change manager', 8, 'change_manager'),
(31, 'Can delete manager', 8, 'delete_manager'),
(32, 'Can view manager', 8, 'view_manager'),
(33, 'Can add employee_ register', 9, 'add_employee_register'),
(34, 'Can change employee_ register', 9, 'change_employee_register'),
(35, 'Can delete employee_ register', 9, 'delete_employee_register'),
(36, 'Can view employee_ register', 9, 'view_employee_register'),
(37, 'Can add lead create', 10, 'add_leadcreate'),
(38, 'Can change lead create', 10, 'change_leadcreate'),
(39, 'Can delete lead create', 10, 'delete_leadcreate'),
(40, 'Can view lead create', 10, 'view_leadcreate'),
(41, 'Can add notes_ details', 11, 'add_notes_details'),
(42, 'Can change notes_ details', 11, 'change_notes_details'),
(43, 'Can delete notes_ details', 11, 'delete_notes_details'),
(44, 'Can view notes_ details', 11, 'view_notes_details'),
(45, 'Can add call_ details', 12, 'add_call_details'),
(46, 'Can change call_ details', 12, 'change_call_details'),
(47, 'Can delete call_ details', 12, 'delete_call_details'),
(48, 'Can view call_ details', 12, 'view_call_details');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$390000$OfwzBZGn0UllgbqdVwABjP$b7TEwg9WcUDqDGnP2FbDBPUGZsXWCrfbq9qdoCrqSPQ=', '2022-12-14 18:24:13.572299', 1, 'mr@shubham123', '', '', '', 0, 1, '2022-12-13 12:21:31.000000'),
(2, 'pbkdf2_sha256$390000$DqS2UjVsdwK4mhhOUZ8aun$KWrr9y1/Nh7KkJa/2MA9h28qqUH/v34loK9OkdWU4wU=', '2022-12-14 16:23:26.234148', 0, 'rolf@123', 'Rolf', 'Smith', 'rolf@gmail.com', 1, 1, '2022-12-13 12:24:08.687346'),
(3, 'pbkdf2_sha256$390000$KVjlPo8Z2Q7gAWfeaYavHh$OE5QbpUSiyEYy1v7vDhQGny2sVOyY7rKC8FK2Q6guuI=', NULL, 0, 'Dipesh223', 'Dipesh', 'Sharma', 'deepak@gmail.com', 1, 1, '2022-12-14 17:04:03.122321'),
(4, 'pbkdf2_sha256$390000$uKsxQ9RV9g6knZgYHeH17D$dy080uSUgOoWq1km/VQjH5NnG0BIjW7hxRFfIZ8q2LQ=', NULL, 0, 'sanju@123', 'sanju', 'dubey', 'sanjay@gmail.com', 1, 1, '2022-12-14 17:05:17.136426'),
(5, 'pbkdf2_sha256$390000$Wo7nIy8ftn9mDw9DNVsfy2$ygv81LnE6Xmqfg9iIVPZGpoIxee+oryWtvPLvfxJqGM=', NULL, 0, 'deep1223', 'Deep', 'N', 'deep@gmail.com', 1, 1, '2022-12-14 18:24:58.414708');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2022-12-13 12:22:26.240800', '1', 'mr@shubham123', 2, '[{\"changed\": {\"fields\": [\"Staff status\"]}}]', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(8, 'Admins', 'manager'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session'),
(7, 'StaffManager', 'teamlead_register'),
(12, 'SuperAdmin', 'call_details'),
(10, 'SuperAdmin', 'leadcreate'),
(11, 'SuperAdmin', 'notes_details'),
(9, 'Teamleader', 'employee_register');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2022-12-13 12:16:48.821512'),
(2, 'auth', '0001_initial', '2022-12-13 12:17:00.730445'),
(3, 'Admins', '0001_initial', '2022-12-13 12:17:03.476492'),
(4, 'SuperAdmin', '0001_initial', '2022-12-13 12:17:14.956695'),
(5, 'StaffManager', '0001_initial', '2022-12-13 12:17:19.220207'),
(6, 'Teamleader', '0001_initial', '2022-12-13 12:17:23.644748'),
(7, 'admin', '0001_initial', '2022-12-13 12:17:27.426160'),
(8, 'admin', '0002_logentry_remove_auto_add', '2022-12-13 12:17:27.551741'),
(9, 'admin', '0003_logentry_add_action_flag_choices', '2022-12-13 12:17:27.670791'),
(10, 'contenttypes', '0002_remove_content_type_name', '2022-12-13 12:17:30.110174'),
(11, 'auth', '0002_alter_permission_name_max_length', '2022-12-13 12:17:31.554852'),
(12, 'auth', '0003_alter_user_email_max_length', '2022-12-13 12:17:31.921135'),
(13, 'auth', '0004_alter_user_username_opts', '2022-12-13 12:17:32.022776'),
(14, 'auth', '0005_alter_user_last_login_null', '2022-12-13 12:17:33.236185'),
(15, 'auth', '0006_require_contenttypes_0002', '2022-12-13 12:17:33.317167'),
(16, 'auth', '0007_alter_validators_add_error_messages', '2022-12-13 12:17:33.545541'),
(17, 'auth', '0008_alter_user_username_max_length', '2022-12-13 12:17:33.854499'),
(18, 'auth', '0009_alter_user_last_name_max_length', '2022-12-13 12:17:34.171135'),
(19, 'auth', '0010_alter_group_name_max_length', '2022-12-13 12:17:34.686939'),
(20, 'auth', '0011_update_proxy_permissions', '2022-12-13 12:17:34.802257'),
(21, 'auth', '0012_alter_user_first_name_max_length', '2022-12-13 12:17:35.104602'),
(22, 'sessions', '0001_initial', '2022-12-13 12:17:36.779213'),
(23, 'StaffManager', '0002_teamlead_register_date', '2022-12-13 12:30:25.815378'),
(24, 'Teamleader', '0002_employee_register_date', '2022-12-13 12:30:26.137570'),
(25, 'StaffManager', '0003_remove_teamlead_register_date_and_more', '2022-12-13 12:37:12.262636'),
(26, 'Teamleader', '0003_alter_employee_register_date', '2022-12-13 12:37:12.330918'),
(27, 'StaffManager', '0004_alter_teamlead_register_created_by_and_more', '2022-12-13 15:41:07.955008'),
(28, 'Teamleader', '0004_alter_employee_register_date', '2022-12-13 15:41:08.068969'),
(29, 'StaffManager', '0005_remove_teamlead_register_lead_ass_and_more', '2022-12-13 16:16:38.564060'),
(30, 'Teamleader', '0005_alter_employee_register_date', '2022-12-13 16:16:38.656264'),
(31, 'StaffManager', '0006_alter_teamlead_register_date_joined', '2022-12-13 17:06:52.700674'),
(32, 'Teamleader', '0006_remove_employee_register_lead_ass_and_more', '2022-12-13 17:06:53.931633');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('s1ej2gz0wu2opisna14548fjyawjal67', '.eJxVjDsOwjAQBe_iGlmsPzFLSZ8zWLv2BgeQI8VJhbg7iZQC2pl5760irUuJa5M5jlldFajTL2NKT6m7yA-q90mnqS7zyHpP9GGb7qcsr9vR_h0UamVbBzhTlz047z06xuAuPnHYgMnsAlgHItakhICG2HUBLVlC8YTDAEF9vq5wNus:1p5RH3:vcqohjzhlZ0SykMgpwQdgc6dbzjwco8GvRh7nAlvNhk', '2022-12-28 18:24:13.656410');

-- --------------------------------------------------------

--
-- Table structure for table `staffmanager_teamlead_register`
--

CREATE TABLE `staffmanager_teamlead_register` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(30) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staffmanager_teamlead_register`
--

INSERT INTO `staffmanager_teamlead_register` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `created_by_id`, `date_joined`) VALUES
(1, 'ddd', 'ds', 'dazy@123', 'dazy@gmail.com', '12345', 1, '2022-12-15 15:47:32.000000'),
(2, 'asdad', 'asd', 'dsd', 'dazy@gmail.com', '12345', 1, '2022-12-13 16:17:04.386376'),
(3, 'Deepak', 'verma', 'Deepak@123', 'deepak@gmail.com', '12345', 1, '2022-12-13 16:18:40.954408'),
(4, 'dsad', 'sdsd', 'csdcd@123', 'sddsadss@gmail.com', '12345', 3, '2022-12-13 16:20:41.961193'),
(5, 'dddddd', 'eeeee', 'ddd', 'ddfsdsdsa@dsdfd', '12345', 1, '2022-12-13 18:37:45.530617'),
(6, 'Rohit', 'sen', 'ro@123', 'rohit12@gmail.com', '12345', 1, '2022-12-14 16:58:45.644130');

-- --------------------------------------------------------

--
-- Table structure for table `superadmin_call_details`
--

CREATE TABLE `superadmin_call_details` (
  `id` bigint(20) NOT NULL,
  `cls` varchar(50) NOT NULL,
  `rem` varchar(250) NOT NULL,
  `str_dt` varchar(50) NOT NULL,
  `end_dt` datetime(6) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `led_id_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `superadmin_leadcreate`
--

CREATE TABLE `superadmin_leadcreate` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `middle_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `gender` varchar(150) NOT NULL,
  `birthday` date NOT NULL,
  `email` varchar(150) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `alternat_no` varchar(12) NOT NULL,
  `address` varchar(300) NOT NULL,
  `permanent_address` varchar(500) NOT NULL,
  `intrested` varchar(150) NOT NULL,
  `lead_sources` varchar(150) NOT NULL,
  `remarks` longtext NOT NULL,
  `assigned` varchar(200) NOT NULL,
  `status` varchar(150) NOT NULL,
  `date_create` date NOT NULL,
  `created_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `superadmin_leadcreate`
--

INSERT INTO `superadmin_leadcreate` (`id`, `first_name`, `middle_name`, `last_name`, `gender`, `birthday`, `email`, `contact`, `alternat_no`, `address`, `permanent_address`, `intrested`, `lead_sources`, `remarks`, `assigned`, `status`, `date_create`, `created_by_id`) VALUES
(1, 'Sanjay', '', 'singh', 'male', '2012-12-20', 'Sanjay@gmail.com', '8787789878', '', 'dsf', 'dsf', 'fd', 'df', 'vfdsdfs fgdgd', '1', '1', '2022-12-08', 2);

-- --------------------------------------------------------

--
-- Table structure for table `superadmin_notes_details`
--

CREATE TABLE `superadmin_notes_details` (
  `id` bigint(20) NOT NULL,
  `msg` varchar(500) NOT NULL,
  `date` datetime(6) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `led_id_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `teamleader_employee_register`
--

CREATE TABLE `teamleader_employee_register` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(30) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teamleader_employee_register`
--

INSERT INTO `teamleader_employee_register` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `created_by_id`, `date`) VALUES
(1, 'Akash', 'lokhande', 'akash12', 'akash@gmail.com', '12345', 3, '2022-12-13 17:45:49.974199'),
(2, 'ssds', 'ssssss', 'sssss', 'ssdwss@ddsss', '12345', 1, '2022-12-13 18:45:03.664192'),
(3, 'dsdasds', 'dasdsa', 'sdd', 'ashu@gmail.com', '12345', 1, '2022-12-13 18:46:49.375655'),
(4, 'shubham', 'verma', 'shubham@123', 'shubhamwqwq@gmail.com', '12345', 1, '2022-12-14 16:56:14.055570');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins_manager`
--
ALTER TABLE `admins_manager`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Admins_manager_created_by_id_8af2f161_fk_auth_user_id` (`created_by_id`);

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `staffmanager_teamlead_register`
--
ALTER TABLE `staffmanager_teamlead_register`
  ADD PRIMARY KEY (`id`),
  ADD KEY `StaffManager_teamlea_created_by_id_11658114_fk_Admins_ma` (`created_by_id`);

--
-- Indexes for table `superadmin_call_details`
--
ALTER TABLE `superadmin_call_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `SuperAdmin_call_details_created_by_id_44e58112_fk_auth_user_id` (`created_by_id`),
  ADD KEY `SuperAdmin_call_deta_led_id_id_cb0e08cc_fk_SuperAdmi` (`led_id_id`);

--
-- Indexes for table `superadmin_leadcreate`
--
ALTER TABLE `superadmin_leadcreate`
  ADD PRIMARY KEY (`id`),
  ADD KEY `SuperAdmin_leadcreate_created_by_id_e94ac789_fk_auth_user_id` (`created_by_id`);

--
-- Indexes for table `superadmin_notes_details`
--
ALTER TABLE `superadmin_notes_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `SuperAdmin_notes_details_created_by_id_50816556_fk_auth_user_id` (`created_by_id`),
  ADD KEY `SuperAdmin_notes_det_led_id_id_ce606a7c_fk_SuperAdmi` (`led_id_id`);

--
-- Indexes for table `teamleader_employee_register`
--
ALTER TABLE `teamleader_employee_register`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Teamleader_employee__created_by_id_a82860e4_fk_StaffMana` (`created_by_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins_manager`
--
ALTER TABLE `admins_manager`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `staffmanager_teamlead_register`
--
ALTER TABLE `staffmanager_teamlead_register`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `superadmin_call_details`
--
ALTER TABLE `superadmin_call_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `superadmin_leadcreate`
--
ALTER TABLE `superadmin_leadcreate`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `superadmin_notes_details`
--
ALTER TABLE `superadmin_notes_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teamleader_employee_register`
--
ALTER TABLE `teamleader_employee_register`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admins_manager`
--
ALTER TABLE `admins_manager`
  ADD CONSTRAINT `Admins_manager_created_by_id_8af2f161_fk_auth_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `staffmanager_teamlead_register`
--
ALTER TABLE `staffmanager_teamlead_register`
  ADD CONSTRAINT `StaffManager_teamlea_created_by_id_11658114_fk_Admins_ma` FOREIGN KEY (`created_by_id`) REFERENCES `admins_manager` (`id`);

--
-- Constraints for table `superadmin_call_details`
--
ALTER TABLE `superadmin_call_details`
  ADD CONSTRAINT `SuperAdmin_call_deta_led_id_id_cb0e08cc_fk_SuperAdmi` FOREIGN KEY (`led_id_id`) REFERENCES `superadmin_leadcreate` (`id`),
  ADD CONSTRAINT `SuperAdmin_call_details_created_by_id_44e58112_fk_auth_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `superadmin_leadcreate`
--
ALTER TABLE `superadmin_leadcreate`
  ADD CONSTRAINT `SuperAdmin_leadcreate_created_by_id_e94ac789_fk_auth_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `superadmin_notes_details`
--
ALTER TABLE `superadmin_notes_details`
  ADD CONSTRAINT `SuperAdmin_notes_det_led_id_id_ce606a7c_fk_SuperAdmi` FOREIGN KEY (`led_id_id`) REFERENCES `superadmin_leadcreate` (`id`),
  ADD CONSTRAINT `SuperAdmin_notes_details_created_by_id_50816556_fk_auth_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `teamleader_employee_register`
--
ALTER TABLE `teamleader_employee_register`
  ADD CONSTRAINT `Teamleader_employee__created_by_id_a82860e4_fk_StaffMana` FOREIGN KEY (`created_by_id`) REFERENCES `staffmanager_teamlead_register` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
