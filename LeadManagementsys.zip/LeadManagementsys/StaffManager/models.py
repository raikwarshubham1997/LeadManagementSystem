from django.db import models
from django.contrib.auth.models import User
from SuperAdmin.models import LeadCreate
from datetime import datetime
from Admins.models import Manager

# Create your models here.
class TeamLead_Register(models.Model):
    # lead_ass = models.ForeignKey(LeadCreate, on_delete=models.CASCADE)
    created_by = models.ForeignKey(Manager, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    username = models.CharField(max_length=50)
    email =  models.EmailField(max_length=200)
    password = models.CharField(max_length=30)
    date_joined = models.DateTimeField(default=datetime.now(), blank=True)