from django.urls import path
from . import views

urlpatterns = [
    path('', views.Employee),
    path('emplogin/', views.login_TL),
    path('register_user/', views.Employee_register),
    path('get_all_lead/', views.get_all_lead),
    path('myemployee/', views.GetEmployeeList)

]