from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import HttpResponse
from .models import *
from companyAdmin.models import LeadCreate
from datetime import datetime
from tablib import Dataset
from django.http import HttpResponse
import xlwt

def hello(request):
    return HttpResponse('Welcome! Leader')


# def simple_upload(request):
#     if request.method == "POST":
#         lead_resource = LeadResource()
#         dataset = Dataset()
#         new_lead = request.FILES['myfile']

#         if not new_lead.name.endswith('xlsx'):
#             messages.info(request, 'Wrong file must be xlsx format!!')
#             return render(request, 'comAdmin/upload_csv.html')
            
        
        
#         imported_data = dataset.load(new_lead.read(),format='xlsx')
#         for data in imported_data:
#             print(data)
#             print('this',request.user.id)
#             value = LeadCreate(
#                 data[0],
#                 data[1],
#                 data[2],
#                 data[3],
#                 data[4],
#                 data[5],
#                 data[6],
#                 data[7],
#                 data[8],
#                 data[9],
#                 data[10],
#                 data[11],
#                 data[12],
#                 data[13],
#                 data[14],
#                 data[15]
                
#                 )
#             value.save()
#         messages.success(request, "File Uploaded Successfull...")
#     return render(request, "comAdmin/upload_csv.html")


'''Function for Export X '''

def Export_xlsx(request):
    response = HttpResponse(content_type='application/ms-excel')   #– This tells browsers that the document is an MS-EXCEL file, instead of an HTML file.
    response['Content-Disposition']= 'attachment; filename="leads.xls"'  #This contains CSV filename and downloads files with that name.

    wb = xlwt.Workbook(encoding='utf-8')         # Creating a Workbook of encoding utf-8
    ws = wb.add_sheet('Leads')                 # Creating a Sheet named “Leads” and all the data will be written inside this sheet.

    # sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold= True

    columns = ['id','first_name', 'middle_name','last_name', 'gender', 'birthday', 'email', 'contact', 'alternat_no','address', 'permanent_address', 'intrested','lead_sources','remarks','assigned','status','date_create']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    #sheet body, remaining rows
    font_style =xlwt.XFStyle()
    user = User.objects.get(id=request.user.id)
    rows = LeadCreate.objects.filter(assigned_id=user).values_list('id','first_name', 'middle_name','last_name', 'gender', 'birthday', 'email', 'contact', 'alternat_no','address', 'permanent_address', 'intrested','lead_sources','remarks','assigned','status','date_create')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)
    return response


def Demo_xlsx(request):
    response = HttpResponse(content_type='application/ms-excel')   #– This tells browsers that the document is an MS-EXCEL file, instead of an HTML file.
    response['Content-Disposition']= 'attachment; filename="leads.xls"'  #This contains CSV filename and downloads files with that name.

    wb = xlwt.Workbook(encoding='utf-8')         # Creating a Workbook of encoding utf-8
    ws = wb.add_sheet('Leads')                 # Creating a Sheet named “Leads” and all the data will be written inside this sheet.

    # sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold= True

    columns = ['id','first_name', 'middle_name','last_name', 'gender', 'birthday', 'email', 'contact', 'alternat_no','address', 'permanent_address', 'intrested','lead_sources','remarks','assigned','status','date_create']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    #sheet body, remaining rows
    font_style =xlwt.XFStyle()

    
    wb.save(response)
    return response
        


"""

Code for lead creation Update Show Delete
"""


def LeadAdmin(request):
    user = User.objects.get(id=request.user.id)
    task = LeadCreate.objects.filter(assigned_id=user).count()
    print(task)

    return render(request, "leads/index.html", {'task':task})
    # return HttpResponse("Welcome Admin")


def ManagerLeads(request):
    user = User.objects.get(id=request.user.id)
    showld = LeadCreate.objects.filter(assigned_id=user)

    return render(request, "leads/mylead.html", {'showld':showld})



def EditLeadInfo(request, id):
    my_users = User.objects.all()
    print(my_users)
    if request.method == 'POST':
        fnm = request.POST['fname']
        mnm = request.POST['mname']
        lnm = request.POST['lname']
        gen = request.POST['gender']
        dob = request.POST['dob']
        email = request.POST['email']
        contact = request.POST['contact']
        alt_contact = request.POST['acontact']
        address = request.POST['address']
        per_address = request.POST['paddress']
        intr = request.POST['intrest']
        lesor = request.POST['leadsource']
        rem = request.POST['remark']
        ass = request.POST['assigned_id']
        status = request.POST['status']
        date = datetime.now()
        # led_id = LeadCreate.objects.get(id=id)
        
        uplead = LeadCreate.objects.filter(id=id)
        
        uplead.update(first_name=fnm,
                            middle_name=mnm,
                            last_name=lnm,
                            gender=gen,
                            birthday=dob,
                            email=email,
                            contact=contact,
                            alternat_no=alt_contact,
                            address=address,
                            permanent_address=per_address,
                            intrested=intr,
                            lead_sources=lesor,
                            remarks=rem,
                            assigned_id=ass,
                            status=status,
                            date_create=date)
        messages.success(request, f"{fnm} Lead Updated Successfully")
        # return redirect('/superadmin/edit_leadinfo//')
        return redirect(request.META.get('HTTP_REFERER', 'redirect_if_referer_not_found'))  
    else:
        mylead = LeadCreate.objects.get(id=id)    
        return render(request, "leads/lead_info_edit.html", {'mylead':mylead, 'my_users':my_users})




def ShowLeadInfo(request, id):
    data = LeadCreate.objects.get(id=id)
    return render(request, "leads/show_lead_info.html", {'data':data})


def DeleteLeadInfo(request, id):
    data = LeadCreate.objects.get(id=id)
    data.delete()
    messages.success(request, f"{data.remarks}, Lead Deleted Succsessfull")
    return redirect('/leadadmin/myLeads/')

def Emp_register(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['pwd']
        created_by = request.user.id
        print(created_by)

        emp = Employee_Register(username=username,email=email,password=password,created_by_id=created_by)
        emp.save()
        messages.success(request, f"{username} Employee Register Successful")
        return redirect('/leadadmin/register_emp/')
    else:
        return render(request, 'leads/signup.html')



