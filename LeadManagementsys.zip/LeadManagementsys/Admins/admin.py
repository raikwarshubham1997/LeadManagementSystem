from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from SuperAdmin.models import LeadCreate


@admin.register(LeadCreate)
class LeadCreate_resource(ImportExportModelAdmin):
    list_display = ('first_name', 'middle_name','last_name', 'gender', 'birthday', 'email', 'contact', 'alternat_no','address', 'permanent_address', 'address', 'intrested','lead_sources','remarks','assigned','status','date_create')



